﻿using System;

namespace desafio1;

class Program
{
    static void Main(string[] args)
    {
        Calculadora calc = new Calculadora("Casio", "1234");

        Console.WriteLine("Suma: " + calc.Sumar(5, 3));
        Console.WriteLine("Resta: " + calc.Restar(5, 3));
        Console.WriteLine("Multiplicación: " + calc.Multiplicar(5, 3));
        Console.WriteLine("División: " + calc.Dividir(5, 3));

        CalculadoraCientifica calcC = new CalculadoraCientifica("HP", "5678");

        Console.WriteLine("Potencia: " + calcC.Potencia(2, 3));
        Console.WriteLine("Raíz: " + calcC.Raiz(16));
        Console.WriteLine("Módulo: " + calcC.Modulo(10, 3));
        Console.WriteLine("Logaritmo: " + calcC.Logaritmo(100));
    }
}

class Calculadora
{
    public string Marca;
    public string Serie;

    public Calculadora(string marca, string serie)
    {
        Marca = marca;
        Serie = serie;
    }

    public double Sumar(double a, double b) => a + b;
    public double Restar(double a, double b) => a - b;
    public double Multiplicar(double a, double b) => a * b;

    public double Dividir(double a, double b)
    {
        if (b != 0) return a / b;
        Console.WriteLine("No se puede dividir entre 0");
        return 0;
    }
}

class CalculadoraCientifica : Calculadora
{
    public CalculadoraCientifica(string marca, string serie) : base(marca, serie) { }

    public double Potencia(double b, double e) => Math.Pow(b, e);
    public double Raiz(double n) => Math.Sqrt(n);
    public double Modulo(double a, double b) => a % b;
    public double Logaritmo(double n) => Math.Log10(n);
}
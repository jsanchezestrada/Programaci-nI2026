﻿using System;

namespace desafio2;

class Program
{
    static void Main(string[] args)
    {
        INotificable email = new NotificacionEmail("correo@gmail.com");
        INotificable whatsapp = new NotificacionWhatsApp("12345678");
        INotificable sms = new NotificacionSMS("87654321");

        email.Notificar();
        whatsapp.Notificar();
        sms.Notificar();
    }
}

interface INotificable
{
    void Notificar();
}

class NotificacionEmail : INotificable
{
    public string direccionCorreo;

    public NotificacionEmail(string correo)
    {
        direccionCorreo = correo;
    }

    public void Notificar()
    {
        Console.WriteLine("Enviando correo a: " + direccionCorreo);
    }
}

class NotificacionWhatsApp : INotificable
{
    public string numeroTelefono;

    public NotificacionWhatsApp(string numero)
    {
        numeroTelefono = numero;
    }

    public void Notificar()
    {
        Console.WriteLine("Enviando WhatsApp a: " + numeroTelefono);
    }
}

class NotificacionSMS : INotificable
{
    public string numeroTelefono;

    public NotificacionSMS(string numero)
    {
        numeroTelefono = numero;
    }

    public void Notificar()
    {
        Console.WriteLine("Enviando SMS a: " + numeroTelefono);
    }
}
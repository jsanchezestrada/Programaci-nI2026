﻿using System;
using System.Collections.Generic;
using System.IO;

namespace desafio_3
{
    class Auto
    {
        protected int HP;
        protected string Color;
        
        protected List<string> reparaciones = new List<string>();
        
        public Auto(int hp, string color)
        {
            HP = hp;
            Color = color;
        }
        
        public virtual void Reparar()
        {
            Console.WriteLine("Auto reparado");
        }
        
        public void HistoriaDeReparaciones()
        {
            string ruta = "reparaciones.txt";

            if (File.Exists(ruta))
            {
                Console.WriteLine("\n=== Historial de Reparaciones ===");

                string[] lineas = File.ReadAllLines(ruta);

                foreach (var linea in lineas)
                {
                    Console.WriteLine(linea);
                }
            }
            else
            {
                Console.WriteLine("No hay historial de reparaciones.");
            }
        }
    }
    
    class BMW : Auto
    {
        private string marca = "BMW";

        public string Modelo { get; set; }
        
        public BMW(int hp, string color, string modelo) : base(hp, color)
        {
            this.Modelo = modelo;
        }
        
        public new void MostrarDetalles()
        {
            Console.WriteLine("Marca: {0} - Modelo: {1} - HP: {2} - Color: {3}",
                marca, Modelo, HP, Color);
        }
        
        public override void Reparar()
        {
            string mensaje = $"El BMW {Modelo} fue reparado el {DateTime.Now}";

            Console.WriteLine(mensaje);
            
            File.AppendAllText("reparaciones.txt", mensaje + Environment.NewLine);
        }
    }
    
    class Program
    {
        static void Main(string[] args)
        {
            BMW miBMW = new BMW(300, "Rojo", "M3");

            miBMW.MostrarDetalles();
            
            miBMW.Reparar();
            miBMW.Reparar();
            miBMW.HistoriaDeReparaciones();
        }
    }
}
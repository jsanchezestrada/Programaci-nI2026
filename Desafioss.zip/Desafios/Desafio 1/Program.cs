﻿using System;

namespace CalculadoraApp
{
    public class Calculadora
    {
        public string Marca { get; set; }
        public string Serie { get; set; }
        
        public double Sumar(double a, double b)
        {
            return a + b;
        }

        public double Restar(double a, double b)
        {
            return a - b;
        }

        public double Multiplicar(double a, double b)
        {
            return a * b;
        }

        public double Dividir(double a, double b)
        {
            if (b == 0)
            {
                Console.WriteLine("No se puede dividir entre cero");
                return 0;
            }
            return a / b;
        }
    }
    
    public class CalculadoraCientifica : Calculadora
    {
        public string Tipo { get; set; }
        
        public double Potencias(double baseNum, double exponente)
        {
            return Math.Pow(baseNum, exponente);
        }

        public double Raiz(double numero)
        {
            return Math.Sqrt(numero);
        }

        public double Modulo(double a, double b)
        {
            return a % b;
        }

        public double Logaritmo(double numero)
        {
            return Math.Log10(numero);
        }
    }
    
    class Program
    {
        static void Main(string[] args)
        {
            Calculadora calc = new Calculadora();
            calc.Marca = "Casio";
            calc.Serie = "123ABC";

            Console.WriteLine("=== Calculadora Básica ===");
            Console.WriteLine("Suma: " + calc.Sumar(5, 3));
            Console.WriteLine("Resta: " + calc.Restar(10, 4));
            Console.WriteLine("Multiplicación: " + calc.Multiplicar(6, 2));
            Console.WriteLine("División: " + calc.Dividir(8, 2));
            
            CalculadoraCientifica calcC = new CalculadoraCientifica();
            calcC.Marca = "HP";
            calcC.Serie = "999XYZ";
            calcC.Tipo = "Científica";

            Console.WriteLine("\n=== Calculadora Científica ===");
            Console.WriteLine("Potencia: " + calcC.Potencias(2, 3));
            Console.WriteLine("Raíz: " + calcC.Raiz(16));
            Console.WriteLine("Módulo: " + calcC.Modulo(10, 3));
            Console.WriteLine("Logaritmo: " + calcC.Logaritmo(100));
        }
    }
}
﻿using System;

namespace NotificacionesApp
{
    public interface INotificable
    {
        void Notifica(string mensaje);
    }
    
    public class NotificacionEmail : INotificable
    {
        public string direccionCorreo { get; set; }

        public void Notifica(string mensaje)
        {
            Console.WriteLine($"Enviando Email a {direccionCorreo}: {mensaje}");
        }
    }
    
    public class NotificacionWhatsap : INotificable
    {
        public string numeroTelefono { get; set; }

        public void Notifica(string mensaje)
        {
            Console.WriteLine($"Enviando WhatsApp a {numeroTelefono}: {mensaje}");
        }
    }
    
    public class NotificacionSMS : INotificable
    {
        public string numeroTelefono { get; set; }

        public void Notifica(string mensaje)
        {
            Console.WriteLine($"Enviando SMS a {numeroTelefono}: {mensaje}");
        }
    }
    
    class Program
    {
        static void Main(string[] args)
        {
            NotificacionEmail email = new NotificacionEmail();
            email.direccionCorreo = "ejemplo@gmail.com";

            NotificacionWhatsap whatsapp = new NotificacionWhatsap();
            whatsapp.numeroTelefono = "12345678";

            NotificacionSMS sms = new NotificacionSMS();
            sms.numeroTelefono = "87654321";
            
            email.Notifica("Hola desde Email");
            whatsapp.Notifica("Hola desde WhatsApp");
            sms.Notifica("Hola desde SMS");
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.IO;

namespace AutosApp
{
    // Clase base
    public class Auto
    {
        public string Marca { get; set; }
        public string Modelo { get; set; }
        
        protected List<string> historialReparaciones = new List<string>();
        
        public virtual void Reparar(string reparacion)
        {
            historialReparaciones.Add(reparacion);
        }
        public virtual void HistoriaDeReparaciones()
        {
            Console.WriteLine("Historial de reparaciones (memoria):");
            foreach (var rep in historialReparaciones)
            {
                Console.WriteLine("- " + rep);
            }
        }
    }
    
    public class BMW : Auto
    {
        private string archivo = "reparaciones.txt";
        public override void Reparar(string reparacion)
        {
            File.AppendAllText(archivo, reparacion + Environment.NewLine);
        }
        
        public override void HistoriaDeReparaciones()
        {
            Console.WriteLine("Historial de reparaciones (archivo):");

            if (File.Exists(archivo))
            {
                string[] lineas = File.ReadAllLines(archivo);
                foreach (var linea in lineas)
                {
                    Console.WriteLine("- " + linea);
                }
            }
            else
            {
                Console.WriteLine("No hay reparaciones registradas.");
            }
        }
    }
    
    class Program
    {
        static void Main(string[] args)
        {
            Auto auto = new Auto();
            auto.Reparar("Cambio de aceite");
            auto.Reparar("Cambio de llantas");
            auto.HistoriaDeReparaciones();

            Console.WriteLine("\n----------------------\n");
            
            BMW bmw = new BMW();
            bmw.Reparar("Reparación de motor");
            bmw.Reparar("Cambio de frenos");

            bmw.HistoriaDeReparaciones();
        }
    }
}
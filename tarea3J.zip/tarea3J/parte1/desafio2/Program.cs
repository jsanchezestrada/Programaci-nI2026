﻿// See https://aka.ms/new-console-template for more information
using System;

class Operaciones
{
    public static int Sumar(int a, int b)
    {
        return a + b;
    }

    public static int Restar(int a, int b)
    {
        return a - b;
    }

    public static int Multiplicar(int a, int b)
    {
        return a * b;
    }

    public static int Dividir(int a, int b)
    {
        return a / b;
    }
}

class Programa
{
    static void Main()
    {
        int n1 = 10;
        int n2 = 5;

        Console.WriteLine("Suma: " + Operaciones.Sumar(n1, n2));
        Console.WriteLine("Resta: " + Operaciones.Restar(n1, n2));
        Console.WriteLine("Multiplicación: " + Operaciones.Multiplicar(n1, n2));
        Console.WriteLine("División: " + Operaciones.Dividir(n1, n2));
    }
}
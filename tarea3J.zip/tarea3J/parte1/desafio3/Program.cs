﻿// See https://aka.ms/new-console-template for more information

using System;

class Programa
{
    static void SumarValores()
    {
        try
        {
            Console.Write("Ingrese el primer valor: ");
            int a = Convert.ToInt32(Console.ReadLine());

            Console.Write("Ingrese el segundo valor: ");
            int b = Convert.ToInt32(Console.ReadLine());

            int suma = a + b;
            Console.WriteLine("La suma es: " + suma);
        }
        catch
        {
            Console.WriteLine("Error: Debe ingresar solo números.");
        }
        finally
        {
            Console.WriteLine("Fin del programa.");
        }
    }

    static void Main()
    {
        SumarValores();
    }
}
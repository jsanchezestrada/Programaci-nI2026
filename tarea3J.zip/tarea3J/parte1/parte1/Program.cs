﻿// See https://aka.ms/new-console-template for more information

using System;

class Programa
{
    static void CalcularIngresos()
    {
        Console.Write("Ingresa tu nombre: ");
        string usuario = Console.ReadLine();

        Console.Write("Ingreso mes 1: ");
        double m1 = Convert.ToDouble(Console.ReadLine());

        Console.Write("Ingreso mes 2: ");
        double m2 = Convert.ToDouble(Console.ReadLine());

        Console.Write("Ingreso mes 3: ");
        double m3 = Convert.ToDouble(Console.ReadLine());

        double suma = m1 + m2 + m3;
        double promedio = suma / 3;

        Console.WriteLine($"Hola {usuario}, en total ganaste {suma} y promediaste {promedio}");
    }

    static void Main()
    {
        CalcularIngresos();
    }
}
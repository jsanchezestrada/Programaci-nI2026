﻿// See https://aka.ms/new-console-template for more information

using System;

class SistemaLogin
{
    static string usuarioRegistrado;
    static string contraseñaRegistrada;

    static void Registrar()
    {
        Console.Write("Crear usuario: ");
        usuarioRegistrado = Console.ReadLine();

        Console.Write("Crear contraseña: ");
        contraseñaRegistrada = Console.ReadLine();

        Console.WriteLine("Usuario registrado correctamente.\n");
    }

    static void IniciarSesion()
    {
        Console.Write("Usuario: ");
        string usuario = Console.ReadLine();

        Console.Write("Contraseña: ");
        string contraseña = Console.ReadLine();

        if (usuario == usuarioRegistrado && contraseña == contraseñaRegistrada)
        {
            Console.WriteLine("Inicio de sesión exitoso.");
        }
        else
        {
            Console.WriteLine("Usuario o contraseña incorrectos.");
        }
    }

    static void Main()
    {
        Registrar();
        IniciarSesion();
    }
}
﻿// See https://aka.ms/new-console-template for more information

using System;

class Juego
{
    static int puntajeRecord = 0;
    static string jugadorRecord = "";

    static void VerificarRecord(int puntaje, string jugador)
    {
        if (puntaje > puntajeRecord)
        {
            puntajeRecord = puntaje;
            jugadorRecord = jugador;

            Console.WriteLine("La nueva puntuación más alta es " + puntajeRecord);
            Console.WriteLine("La puntuación más alta fue lograda por " + jugadorRecord);
        }
    }

    static void Main()
    {
        VerificarRecord(50, "Ana");
        VerificarRecord(120, "Luis");
        VerificarRecord(80, "Carlos");
    }
}